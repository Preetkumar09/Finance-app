# FinanceOS — Personal Finance Dashboard

A clean, responsive personal finance dashboard built with React. Track your income, expenses, view trends, and manage transactions — all with role-based access control.

---

## Features

- **Summary Cards** — Total Balance, Income, and Expenses at a glance
- **Trend Chart** — Line graph of income vs expenses over time (Recharts)
- **Breakdown Chart** — Pie chart of expense categories
- **Transaction Table** — Full list with sortable columns (date, amount)
- **Search & Filter** — Filter by text, type (income/expense), and category
- **Role-Based Access**
  - `Viewer` — Read-only mode, no add/delete controls
  - `Admin` — Full control: add and delete transactions
- **Add Transaction Modal** — Form with validation (Admin only)
- **Smart Insights** — Auto-generated insight about your top spending category
- **Empty State** — Graceful fallback when no transactions match filters
- **Responsive** — Works on mobile, tablet, and desktop

---

## Tech Stack

| Layer      | Tool                          |
|------------|-------------------------------|
| Framework  | React 18                      |
| Charts     | Recharts                      |
| Icons      | Lucide React                  |
| Styling    | Custom CSS (design tokens)    |
| Fonts      | Syne + DM Mono (Google Fonts) |
| State      | React Hooks (`useState`, `useMemo`) |

---

## Getting Started

### Prerequisites
- Node.js v16+ and npm

### Installation

```bash
# 1. Clone or unzip the project
cd finance-app

# 2. Install dependencies
npm install

# 3. Start the dev server
npm start
```

The app opens at **http://localhost:3000**

### Build for Production

```bash
npm run build
```

Output is in the `/build` folder — ready to deploy on Vercel, Netlify, or any static host.

---

## Project Structure

```
finance-app/
├── public/
│   └── index.html
├── src/
│   ├── components/
│   │   ├── SummaryCards.jsx   # Balance / Income / Expense cards
│   │   ├── Charts.jsx         # Line chart + Pie chart
│   │   ├── Filters.jsx        # Search bar, type pills, category dropdown
│   │   ├── TransactionTable.jsx  # Sortable table with empty state
│   │   ├── InsightBanner.jsx  # Auto-insight display
│   │   └── AddModal.jsx       # Add transaction form modal
│   ├── data/
│   │   └── transactions.js    # 30 fake transactions + category config
│   ├── hooks/
│   │   └── useFinance.js      # All state logic & derived data
│   ├── App.jsx                # Root layout + header
│   └── App.css                # Full design system CSS
└── package.json
```

---

## Design Decisions

- **No localStorage / backend** — All state lives in React memory (as required)
- **Custom CSS** — No Tailwind dependency; design tokens (`--accent`, `--surface`, etc.) ensure consistency
- **useMemo** — Filtering, sorting, summary stats, and chart data are memoized to avoid unnecessary recalculations
- **Empty state** — The table gracefully shows a "No transactions found" illustration instead of breaking
- **Fake data** — 30 realistic transactions across 11 categories spanning June 2024

---

## Role Switching

Use the **Viewer / Admin** toggle in the top-right corner:

| Action             | Viewer | Admin |
|--------------------|--------|-------|
| View dashboard     | ✅     | ✅    |
| Search & filter    | ✅     | ✅    |
| Add transaction    | ❌     | ✅    |
| Delete transaction | ❌     | ✅    |

---

## Screenshots

Start the app locally to view the dashboard. It ships with 30 pre-loaded transactions.
