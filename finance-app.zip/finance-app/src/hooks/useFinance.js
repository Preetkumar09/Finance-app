import { useState, useMemo } from "react";
import { transactions as initialTransactions } from "../data/transactions";

export function useFinance() {
  const [transactions, setTransactions] = useState(initialTransactions);
  const [role, setRole] = useState("viewer"); // "viewer" | "admin"
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("all"); // "all" | "income" | "expense"
  const [filterCategory, setFilterCategory] = useState("All");
  const [sortField, setSortField] = useState("date");
  const [sortDir, setSortDir] = useState("desc");

  const filtered = useMemo(() => {
    let list = [...transactions];
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (t) =>
          t.description.toLowerCase().includes(q) ||
          t.category.toLowerCase().includes(q)
      );
    }
    if (filterType !== "all") list = list.filter((t) => t.type === filterType);
    if (filterCategory !== "All") list = list.filter((t) => t.category === filterCategory);
    list.sort((a, b) => {
      let va = a[sortField], vb = b[sortField];
      if (sortField === "date") { va = new Date(va); vb = new Date(vb); }
      return sortDir === "asc" ? (va > vb ? 1 : -1) : (va < vb ? 1 : -1);
    });
    return list;
  }, [transactions, search, filterType, filterCategory, sortField, sortDir]);

  const summary = useMemo(() => {
    const income  = transactions.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
    const expense = transactions.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
    return { income, expense, balance: income - expense };
  }, [transactions]);

  const trendData = useMemo(() => {
    const map = {};
    transactions.forEach((t) => {
      const day = t.date;
      if (!map[day]) map[day] = { date: day, income: 0, expense: 0 };
      if (t.type === "income") map[day].income += t.amount;
      else map[day].expense += t.amount;
    });
    return Object.values(map).sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [transactions]);

  const pieData = useMemo(() => {
    const map = {};
    transactions
      .filter((t) => t.type === "expense")
      .forEach((t) => {
        map[t.category] = (map[t.category] || 0) + t.amount;
      });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [transactions]);

  const insight = useMemo(() => {
    if (!transactions.length) return "No transactions yet. Add one to get started!";
    const expMap = {};
    transactions.filter((t) => t.type === "expense").forEach((t) => {
      expMap[t.category] = (expMap[t.category] || 0) + t.amount;
    });
    const top = Object.entries(expMap).sort((a, b) => b[1] - a[1])[0];
    if (!top) return "No expenses recorded yet.";
    return `Your biggest spending category is ${top[0]} — ₹${top[1].toLocaleString("en-IN")} this month.`;
  }, [transactions]);

  const addTransaction = (tx) => {
    setTransactions((prev) => [{ ...tx, id: Date.now() }, ...prev]);
  };

  const deleteTransaction = (id) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const toggleSort = (field) => {
    if (sortField === field) setSortDir((d) => (d === "asc" ? "desc" : "asc"));
    else { setSortField(field); setSortDir("desc"); }
  };

  return {
    role, setRole,
    search, setSearch,
    filterType, setFilterType,
    filterCategory, setFilterCategory,
    sortField, sortDir, toggleSort,
    filtered, summary, trendData, pieData, insight,
    addTransaction, deleteTransaction,
  };
}
