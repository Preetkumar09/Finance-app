import React from "react";
import { TrendingUp, TrendingDown, Wallet } from "lucide-react";

function fmt(n) {
  return "₹" + n.toLocaleString("en-IN");
}

function Card({ label, value, icon: Icon, color, sub }) {
  return (
    <div className={`summary-card ${color}`}>
      <div className="card-icon">
        <Icon size={20} />
      </div>
      <div className="card-body">
        <p className="card-label">{label}</p>
        <p className="card-value">{fmt(value)}</p>
        {sub && <p className="card-sub">{sub}</p>}
      </div>
    </div>
  );
}

export default function SummaryCards({ summary }) {
  return (
    <div className="summary-grid">
      <Card label="Total Balance"  value={summary.balance}  icon={Wallet}      color="card-balance" sub="Current net" />
      <Card label="Total Income"   value={summary.income}   icon={TrendingUp}  color="card-income"  sub="All time income" />
      <Card label="Total Expenses" value={summary.expense}  icon={TrendingDown} color="card-expense" sub="All time expenses" />
    </div>
  );
}
