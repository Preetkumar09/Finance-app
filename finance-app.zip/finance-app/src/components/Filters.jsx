import React from "react";
import { Search, X } from "lucide-react";
import { CATEGORIES } from "../data/transactions";

export default function Filters({
  search, setSearch,
  filterType, setFilterType,
  filterCategory, setFilterCategory,
}) {
  return (
    <div className="filters-bar">
      <div className="search-wrap">
        <Search size={15} className="search-icon" />
        <input
          className="search-input"
          type="text"
          placeholder="Search transactions…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        {search && (
          <button className="clear-btn" onClick={() => setSearch("")}>
            <X size={13} />
          </button>
        )}
      </div>

      <div className="filter-pills">
        {["all", "income", "expense"].map((t) => (
          <button
            key={t}
            className={`pill ${filterType === t ? "pill-active" : ""}`}
            onClick={() => setFilterType(t)}
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      <select
        className="cat-select"
        value={filterCategory}
        onChange={(e) => setFilterCategory(e.target.value)}
      >
        {CATEGORIES.map((c) => (
          <option key={c} value={c}>{c}</option>
        ))}
      </select>
    </div>
  );
}
