import React from "react";
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend,
  PieChart, Pie, Cell, Tooltip as PieTooltip
} from "recharts";
import { CATEGORY_COLORS } from "../data/transactions";

function shortDate(d) {
  const [, m, day] = d.split("-");
  return `${day}/${m}`;
}

function rupeeFmt(v) {
  return "₹" + Number(v).toLocaleString("en-IN");
}

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="chart-tooltip">
      <p className="tt-label">{label}</p>
      {payload.map((p) => (
        <p key={p.name} style={{ color: p.color }}>
          {p.name}: {rupeeFmt(p.value)}
        </p>
      ))}
    </div>
  );
};

const PieCustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const { name, value } = payload[0];
  return (
    <div className="chart-tooltip">
      <p>{name}: {rupeeFmt(value)}</p>
    </div>
  );
};

const RADIAN = Math.PI / 180;
const renderLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }) => {
  if (percent < 0.06) return null;
  const r = innerRadius + (outerRadius - innerRadius) * 0.5;
  const x = cx + r * Math.cos(-midAngle * RADIAN);
  const y = cy + r * Math.sin(-midAngle * RADIAN);
  return (
    <text x={x} y={y} fill="#fff" textAnchor="middle" dominantBaseline="central" fontSize={11} fontWeight={600}>
      {(percent * 100).toFixed(0)}%
    </text>
  );
};

export default function Charts({ trendData, pieData }) {
  const hasTrend = trendData.length > 0;
  const hasPie   = pieData.length  > 0;

  return (
    <div className="charts-row">
      <div className="chart-card">
        <h3 className="chart-title">Balance Trend</h3>
        {hasTrend ? (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={trendData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="date" tickFormatter={shortDate} tick={{ fontSize: 11, fill: "var(--text-muted)" }} />
              <YAxis tickFormatter={(v) => "₹" + (v / 1000).toFixed(0) + "k"} tick={{ fontSize: 11, fill: "var(--text-muted)" }} />
              <Tooltip content={<CustomTooltip />} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="income"  stroke="#6EE7B7" strokeWidth={2} dot={false} name="Income" />
              <Line type="monotone" dataKey="expense" stroke="#F87171" strokeWidth={2} dot={false} name="Expense" />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="empty-chart">No trend data yet.</div>
        )}
      </div>

      <div className="chart-card">
        <h3 className="chart-title">Expense Breakdown</h3>
        {hasPie ? (
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                outerRadius={90}
                dataKey="value"
                labelLine={false}
                label={renderLabel}
              >
                {pieData.map((entry) => (
                  <Cell key={entry.name} fill={CATEGORY_COLORS[entry.name] || "#94a3b8"} />
                ))}
              </Pie>
              <PieTooltip content={<PieCustomTooltip />} />
              <Legend
                layout="vertical"
                align="right"
                verticalAlign="middle"
                iconType="circle"
                iconSize={8}
                wrapperStyle={{ fontSize: 11 }}
              />
            </PieChart>
          </ResponsiveContainer>
        ) : (
          <div className="empty-chart">No expense data yet.</div>
        )}
      </div>
    </div>
  );
}
