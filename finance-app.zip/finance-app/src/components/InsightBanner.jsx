import React from "react";
import { Lightbulb } from "lucide-react";

export default function InsightBanner({ insight }) {
  return (
    <div className="insight-bar">
      <Lightbulb size={16} className="insight-icon" />
      <p className="insight-text">{insight}</p>
    </div>
  );
}
