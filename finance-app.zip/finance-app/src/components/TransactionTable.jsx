import React from "react";
import { Trash2, ArrowUpDown, ArrowUp, ArrowDown, ReceiptText } from "lucide-react";
import { CATEGORY_COLORS } from "../data/transactions";

function SortIcon({ field, sortField, sortDir }) {
  if (sortField !== field) return <ArrowUpDown size={13} className="sort-neutral" />;
  return sortDir === "asc" ? <ArrowUp size={13} className="sort-active" /> : <ArrowDown size={13} className="sort-active" />;
}

export default function TransactionTable({ transactions, role, onDelete, sortField, sortDir, toggleSort }) {
  if (transactions.length === 0) {
    return (
      <div className="empty-state">
        <ReceiptText size={48} className="empty-icon" />
        <p className="empty-title">No transactions found</p>
        <p className="empty-sub">Try adjusting your search or filters.</p>
      </div>
    );
  }

  return (
    <div className="table-wrap">
      <table className="tx-table">
        <thead>
          <tr>
            <th onClick={() => toggleSort("date")} className="th-sort">
              Date <SortIcon field="date" sortField={sortField} sortDir={sortDir} />
            </th>
            <th>Description</th>
            <th>Category</th>
            <th onClick={() => toggleSort("amount")} className="th-sort">
              Amount <SortIcon field="amount" sortField={sortField} sortDir={sortDir} />
            </th>
            <th>Type</th>
            {role === "admin" && <th>Action</th>}
          </tr>
        </thead>
        <tbody>
          {transactions.map((tx) => (
            <tr key={tx.id} className="tx-row">
              <td className="td-date">{tx.date}</td>
              <td className="td-desc">{tx.description}</td>
              <td>
                <span
                  className="cat-badge"
                  style={{ background: (CATEGORY_COLORS[tx.category] || "#94a3b8") + "22", color: CATEGORY_COLORS[tx.category] || "#94a3b8" }}
                >
                  {tx.category}
                </span>
              </td>
              <td className={`td-amount ${tx.type === "income" ? "income-amt" : "expense-amt"}`}>
                {tx.type === "income" ? "+" : "-"}₹{tx.amount.toLocaleString("en-IN")}
              </td>
              <td>
                <span className={`type-badge ${tx.type}`}>
                  {tx.type.charAt(0).toUpperCase() + tx.type.slice(1)}
                </span>
              </td>
              {role === "admin" && (
                <td>
                  <button className="del-btn" onClick={() => onDelete(tx.id)} title="Delete">
                    <Trash2 size={14} />
                  </button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
