import React, { useState } from "react";
import { X } from "lucide-react";
import { CATEGORIES } from "../data/transactions";

const cats = CATEGORIES.filter((c) => c !== "All");

export default function AddModal({ onClose, onAdd }) {
  const [form, setForm] = useState({
    date: new Date().toISOString().split("T")[0],
    description: "",
    amount: "",
    type: "expense",
    category: "Food",
  });
  const [error, setError] = useState("");

  const handle = (e) => setForm((f) => ({ ...f, [e.target.name]: e.target.value }));

  const submit = () => {
    if (!form.description.trim()) return setError("Description is required.");
    if (!form.amount || isNaN(form.amount) || +form.amount <= 0) return setError("Enter a valid amount.");
    onAdd({ ...form, amount: +form.amount });
    onClose();
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Add Transaction</h2>
          <button className="modal-close" onClick={onClose}><X size={18} /></button>
        </div>

        <div className="modal-body">
          <label className="field-label">Date</label>
          <input className="field-input" type="date" name="date" value={form.date} onChange={handle} />

          <label className="field-label">Description</label>
          <input className="field-input" type="text" name="description" placeholder="e.g. Amazon order" value={form.description} onChange={handle} />

          <label className="field-label">Amount (₹)</label>
          <input className="field-input" type="number" name="amount" placeholder="0" value={form.amount} onChange={handle} />

          <div className="field-row">
            <div style={{ flex: 1 }}>
              <label className="field-label">Type</label>
              <select className="field-input" name="type" value={form.type} onChange={handle}>
                <option value="income">Income</option>
                <option value="expense">Expense</option>
              </select>
            </div>
            <div style={{ flex: 1 }}>
              <label className="field-label">Category</label>
              <select className="field-input" name="category" value={form.category} onChange={handle}>
                {cats.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>

          {error && <p className="field-error">{error}</p>}
        </div>

        <div className="modal-footer">
          <button className="btn-cancel" onClick={onClose}>Cancel</button>
          <button className="btn-add" onClick={submit}>Add Transaction</button>
        </div>
      </div>
    </div>
  );
}
