import React, { useState } from "react";
import SummaryCards from "./components/SummaryCards";
import Charts from "./components/Charts";
import Filters from "./components/Filters";
import TransactionTable from "./components/TransactionTable";
import InsightBanner from "./components/InsightBanner";
import AddModal from "./components/AddModal";
import { useFinance } from "./hooks/useFinance";
import { PlusCircle, LayoutDashboard, ShieldCheck, Eye } from "lucide-react";
import "./App.css";

export default function App() {
  const [showModal, setShowModal] = useState(false);
  const {
    role, setRole,
    search, setSearch,
    filterType, setFilterType,
    filterCategory, setFilterCategory,
    sortField, sortDir, toggleSort,
    filtered, summary, trendData, pieData, insight,
    addTransaction, deleteTransaction,
  } = useFinance();

  return (
    <div className="app">
      {/* ── Header ── */}
      <header className="topbar">
        <div className="brand">
          <LayoutDashboard size={22} />
          <span>FinanceOS</span>
        </div>

        <div className="header-right">
          {/* Role toggle */}
          <div className="role-toggle">
            <button
              className={`role-btn ${role === "viewer" ? "role-active" : ""}`}
              onClick={() => setRole("viewer")}
            >
              <Eye size={14} /> Viewer
            </button>
            <button
              className={`role-btn ${role === "admin" ? "role-active admin-role" : ""}`}
              onClick={() => setRole("admin")}
            >
              <ShieldCheck size={14} /> Admin
            </button>
          </div>

          {/* Add button — admin only */}
          {role === "admin" && (
            <button className="add-btn" onClick={() => setShowModal(true)}>
              <PlusCircle size={16} />
              <span>Add Transaction</span>
            </button>
          )}
        </div>
      </header>

      <main className="main">
        {/* Role badge */}
        <div className="role-banner">
          {role === "admin"
            ? "🛡️ Admin Mode — you can add and delete transactions."
            : "👁️ Viewer Mode — read-only access."}
        </div>

        {/* Summary cards */}
        <SummaryCards summary={summary} />

        {/* Charts */}
        <Charts trendData={trendData} pieData={pieData} />

        {/* Insight */}
        <InsightBanner insight={insight} />

        {/* Transactions section */}
        <section className="tx-section">
          <div className="tx-header">
            <h2 className="section-title">Transactions
              <span className="tx-count">{filtered.length}</span>
            </h2>
          </div>

          <Filters
            search={search} setSearch={setSearch}
            filterType={filterType} setFilterType={setFilterType}
            filterCategory={filterCategory} setFilterCategory={setFilterCategory}
          />

          <TransactionTable
            transactions={filtered}
            role={role}
            onDelete={deleteTransaction}
            sortField={sortField}
            sortDir={sortDir}
            toggleSort={toggleSort}
          />
        </section>
      </main>

      {showModal && (
        <AddModal onClose={() => setShowModal(false)} onAdd={addTransaction} />
      )}
    </div>
  );
}
